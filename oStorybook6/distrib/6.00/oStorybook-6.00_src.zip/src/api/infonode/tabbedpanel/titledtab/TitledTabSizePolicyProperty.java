/*
 * Copyright (C) 2004 NNL Technology AB
 * Visit www.infonode.net for information about InfoNode(R) 
 * products and how to contact NNL Technology AB.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, 
 * MA 02111-1307, USA.
 */


// $Id: TitledTabSizePolicyProperty.java,v 1.6 2005/02/16 11:28:15 jesper Exp $
package api.infonode.tabbedpanel.titledtab;

import api.infonode.properties.base.PropertyGroup;
import api.infonode.properties.types.EnumProperty;
import api.infonode.properties.util.PropertyValueHandler;

/**
 * Property for TitledTabSizePolicy
 *
 * @author $Author: jesper $
 * @version $Revision: 1.6 $
 * @see TitledTabSizePolicy
 */
public class TitledTabSizePolicyProperty extends EnumProperty {
  /**
   * Constructs a TitledTabSizePolicyProperty object.
   *
   * @param group        property group
   * @param name         property name
   * @param description  property description
   * @param valueStorage storage for property
   */
  public TitledTabSizePolicyProperty(PropertyGroup group,
                                     String name,
                                     String description,
                                     PropertyValueHandler valueStorage) {
    super(group, name, TitledTabSizePolicy.class, description, valueStorage, TitledTabSizePolicy.getSizePolicies());
  }

  /**
   * Gets the TitledTabSizePolicy
   *
   * @param object storage object for property
   * @return the TitledTabSizePolicy
   */
  public TitledTabSizePolicy get(Object object) {
    return (TitledTabSizePolicy) getValue(object);
  }

  /**
   * Sets the TitledTabSizePolicy
   *
   * @param object storage object for property
   * @param policy the TitledTabSizePolicy
   */
  public void set(Object object, TitledTabSizePolicy policy) {
    setValue(object, policy);
  }
}
