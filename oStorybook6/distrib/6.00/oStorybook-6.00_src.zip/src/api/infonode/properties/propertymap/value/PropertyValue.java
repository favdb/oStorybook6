/*
 * Copyright (C) 2004 NNL Technology AB
 * Visit www.infonode.net for information about InfoNode(R) 
 * products and how to contact NNL Technology AB.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, 
 * MA 02111-1307, USA.
 */


// $Id: PropertyValue.java,v 1.10 2005/03/17 16:15:32 jesper Exp $
package api.infonode.properties.propertymap.value;

import api.infonode.properties.propertymap.PropertyMapImpl;
import api.infonode.util.Printer;

import java.io.IOException;
import java.io.ObjectOutputStream;

/**
 * @author $Author: jesper $
 * @version $Revision: 1.10 $
 */
public interface PropertyValue {
  Object get(PropertyMapImpl map);

  Object getWithDefault(PropertyMapImpl object);

  PropertyValue getSubValue(PropertyMapImpl object);

  void unset();

  PropertyValue getParent();

  void dump(Printer printer);

  void write(ObjectOutputStream out) throws IOException;

  void updateListener(boolean enable);

  boolean isSerializable();

  PropertyValue copyTo(PropertyMapImpl propertyMap);
}
